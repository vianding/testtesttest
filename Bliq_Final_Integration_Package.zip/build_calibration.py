import os,csv,math,zipfile
from collections import defaultdict
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import inch
from xml.sax.saxutils import escape
base='/mnt/data/bliq_calibration_final'; src='/mnt/data/bliq_calibration_v07'
read=lambda n:list(csv.DictReader(open(os.path.join(src,n),encoding='utf-8-sig')))
events=read('event_evidence_register.csv'); scenarios=read('scenario_parameters.csv'); decomp=read('calibration_decomposition.csv'); cross=read('event_market_haircut_crosswalk.csv'); daily=read('normalized_daily_history.csv')
# Repair v0.7 selection-register ISIN serialization bug from normalized original history.
selection=read('selection_register.csv'); lookup={}
for r in daily: lookup[(r['episode'],r['isin'])]=r
correct=[]
for e in sorted(set(x['episode'] for x in daily)):
 for isin in sorted(set(x['isin'] for x in daily if x['episode']==e)):
  match=[x for x in selection if x['episode']==e and isin in x.get('isin','')]
  if not match:
   match=[x for x in selection if x['episode']==e and x['security']==lookup[(e,isin)]['security']]
  r=dict(match[0]) if match else {'episode':e,'security':lookup[(e,isin)]['security'],'tier':'','coverage_pct':'','window_mean_bid':'','event_bid':'','selection_reason':'','central_weight_policy':'','source':''}
  r['isin']=isin;correct.append(r)
with open(base+'/selection_register_corrected.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(correct[0]));w.writeheader();w.writerows(correct)
for n in ['scenario_parameters.csv','calibration_decomposition.csv','event_evidence_register.csv','event_market_haircut_crosswalk.csv','macro_event_crosswalk.csv','market_macro_diagnostics.csv','event_selection_sensitivity.csv','normalized_daily_history.csv','individual_restructurings_clean.csv','balanced_sensitivity.csv']:
 import shutil;shutil.copy2(src+'/'+n,base+'/'+n)
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='DocTitleX',parent=styles['Title'],fontName='Helvetica-Bold',fontSize=19,leading=23,spaceAfter=12,textColor=colors.HexColor('#17334b')))
styles.add(ParagraphStyle(name='HeadingX',parent=styles['Heading2'],fontSize=11.5,leading=15,spaceBefore=13,spaceAfter=6,textColor=colors.HexColor('#17334b')))
styles.add(ParagraphStyle(name='BodyX',parent=styles['BodyText'],fontSize=8.8,leading=13,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallX',parent=styles['BodyText'],fontSize=7.3,leading=10,spaceAfter=4))
styles.add(ParagraphStyle(name='TableX',parent=styles['BodyText'],fontSize=7.3,leading=10))
story=[];md=[]
def title(t):story.append(Paragraph(escape(t),styles['DocTitleX']));md.append('# '+t+'\n')
def h(t):story.append(Paragraph(escape(t),styles['HeadingX']));md.append('\n## '+t+'\n')
def p(t):story.append(Paragraph(t,styles['BodyX']));md.append(t.replace('<b>','**').replace('</b>','**').replace('<i>','*').replace('</i>','*')+'\n')
def small(t):story.append(Paragraph(t,styles['SmallX']));md.append(t+'\n')
def table(headers,rows,widths=None):
 data=[[Paragraph('<b>'+escape(str(x))+'</b>',styles['TableX']) for x in headers]]+[[Paragraph(escape(str(x)),styles['TableX']) for x in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e9f0f4')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#8095a3')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f7f9fa')]),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.append(t);story.append(Spacer(1,9))
 md.append('| '+' | '.join(headers)+' |\n|'+'|'.join(['---']*len(headers))+'|\n');md.extend('| '+' | '.join(str(x).replace('|','/') for x in row)+' |\n' for row in rows)
title('SPIRE | French OAT€i collateral liquidation calibration')
small('Independent, self-contained decision paper | Final research edition | 15 October 2026 | Senior quant / desk review | Not yet production approved')
h('Executive conclusion and recommended model input')
p('We recommend an explicit <b>conditional-on-French-default, scenario-based recovery on indexed principal</b>. This separates market accessibility from realized sale value, captures the positive-part loss nonlinearity, and is auditable. It is a proportionate improvement: no unvalidated sovereign macro forecast or elaborate stochastic default model is required.')
table(['Use','Mean recovery / indexed face','No-access assumption','Illustrative expected loss'],[['Central (Balanced)','36.00%','10%','EUR 3.50m'],['Downside (Conservative)','19.75%','25%','EUR 8.24m'],['Upside (Aggressive)','53.75%','5%','EUR 1.40m']],[113,118,123,132])
p('<b>Decision:</b> adopt Balanced as a <b>provisional working conditional recovery distribution</b>, not as a statistical prediction or a signed-off production parameter. Retain downside/upside as sensitivity sets, not confidence intervals. The 36% scalar is useful for communication; CVA must average losses across states. There is no statistically defensible France-specific macro uplift from the current sample. Closing the research at this point is preferable to adding unsupported complexity.')
p('<b>Normalization:</b> recovery is measured against indexed face F = N x IR, not pre-default market value. The recovery distribution represents accessible proceeds within the applicable close-out/disposal convention, not ultimate creditor recovery. Distinguish indexed principal, accrued coupons and legal claim recognition; do not infer the recovery denominator from a bond clean-price quotation.')
h('1 | Scope, contractual boundary and quantities')
p('Transaction: SPIRE Series XS3411888731, underlying French inflation-linked OAT EUR i FR0013209871, 0.10%, July 2047. The task is to estimate <b>net collateral value accessible for the relevant close-out</b> after hypothetical French sovereign distress, under applicable disposal provisions. It is not a prediction of French default probability, nor a revaluation of the entire XVA engine.')
p('Let F = N(base face) x IR(reference), and R(k) = B_available(k)/F. For each scenario k, B_available(k)=F x R(k) after any required accessibility, execution, costs and waterfall treatment; L(k)=max[V_closeout(k)-B_available(k),0]. Average conditional loss = sum_k w(k)L(k). Do not compute max[V-E(B),0] or apply a second collateral LGD. The actual close-out and F may co-move with the default state.')
p('The 2025 SPIRE Base Prospectus establishes a series-dependent liquidation period. The 30 TARGET-business-day window is the <b>research convention</b>, not verified executed-Series election; the actual Reference Business Day definition, sale rights, CSA, waterfall and agent obligations remain contractual verification gates. A zero-access state means no cash credited within the relevant close-out window; it does <b>not</b> assert zero ultimate creditor recovery.')
h('2 | Four economic quantities, four distinct evidence roles')
table(['Quantity / estimand','Data / statistical unit','Permitted use','Not supported'],[['Default-window indicative bid','Bloomberg BVAL daily bids; bond observations nested in 7 events','Market stress anchors, time path, quote coverage','Executable block sale or French default probability'],['Ultimate restructuring NPV recovery','April 2025 haircut database; restructuring records','Severity distribution, external plausibility checks','30-day liquidation price'],['French default-state OAT EUR i market value','France-specific transfer assumptions informed by historical evidence','Conditional market-value scenario range','A fitted France point prediction'],['Net SPIRE accessible proceeds','Scenario accessibility, sale execution and contract','CVA collateral input and pathwise loss','Inference directly from BVAL or haircut data']],[111,137,140,98])
p('The descriptive Bloomberg statistic is the average of <b>available</b> T0-T30 TARGET bids, not a hypothetical optimal or realized sale policy. Restructuring recovery = 1 minus the published NPV haircut, under the authors\' discounting and legal conventions. Matching both by sovereign/year is a <b>diagnostic crosswalk</b>, not a generic bid-to-haircut spread estimator. Neither historical quote absence nor exchange-driven cessation is coded as zero liquidation proceeds.')
h('3 | Bloomberg sample: adequate for anchors, not statistically representative')
p('The supplied Bloomberg research summary and exports establish <b>22 distinct ISINs in seven event clusters</b>: 6 original Zambia/Ghana and 16 additional Greece/Ecuador/Argentina/Ukraine securities. The summary discussed 17 windows but 16 distinct new instruments were supplied; the 2024 Ukraine ISIN substitutions reflect actual query availability. BVAL-availability selection is nonrandom and may favor priceable bonds. Sovereign events, not individual bonds or days, are the effective independent units.')
table(['Episode','Bonds','Tier','T0-T30 mean BVAL bid','Role'],[['Greece 2012','1','C','18.6','English-law bond; not Greek-law PSI representative'],['Ecuador 2020','2','B','34.0','Different claim structures; COVID overlap'],['Argentina 2020','3','A','37.2','Default-window primary comparator'],['Zambia 2020','3','A','49.0','Default-window primary comparator'],['Ghana 2022','3','A','37.0','Default-window primary comparator'],['Ukraine 2015','5','C','76.9','Post-agreement repricing; not initial default'],['Ukraine 2024','5','B','33.7','Substituted ISINs; exchange-driven missingness']],[96,38,35,105,212])
p('A/B/C are qualitative <b>research-use tiers</b>, not probability weights. Equal-event mean bid is 41.1 for Tier A (n=3 events), 38.2 for A+B (n=5), and 40.9 for all seven; corresponding medians 37.2, 37.0 and 37.0. The wide changes and noncomparable episodes argue against a single pooled regression. All 22 bonds are retained in the appendix inventory, with corrected ISIN identifiers.')
h('4 | Ultimate restructuring outcomes: independent check, not liquidation calibration')
p('The April 2025 haircut workbook contains 329 individual restructuring records; the specified modern filter (1970-2024) has 193 records and 184 with NPV haircuts bounded between 0 and 100%. Median NPV haircut is 34.25%, hence median implied recovery 65.75%. This is a <b>restructuring-outcome</b> statistic, not the expected proceeds from a 30-day forced sale.')
table(['Episode','Market-window mean bid','Published implied NPV recovery'],[['Greece 2012','18.6','35.4%'],['Ecuador 2020','34.0','58.8%'],['Argentina 2020','37.2','65.4%'],['Zambia 2020','49.0','36.4%'],['Ghana 2022','37.0','54.6%'],['Ukraine 2015','76.9','78.8%'],['Ukraine 2024','33.7','No matched 2024 record']],[120,160,206])
p('These are <b>country/event matches, not identical security and valuation-date matches</b>. Market bids incorporate expected negotiation, time-to-exchange, liquidity and legal claims; restructuring NPV incorporates later outcomes and study discount rates. Their numerical differences cannot be interpreted as an execution haircut. Cruces-Trebesch 2014 and BoC-BoE DEBT_2025 provide historical-methodology and default classification cross-checks; they do not identify saleability.')
h('5 | Transfer to France: deliberate and limited')
p('<b>Economic/fiscal channel.</b> Pre-event debt/GDP versus the seven market-window prices has Pearson r = -0.51 for all seven, +0.54 for A+B, and +0.68 for Tier A. The sign reversal across event selections invalidates a mechanically fitted French adjustment. The broad haircut panel lacks a harmonized point-in-time fiscal covariate panel in the current research package; no robust macro-to-France restructuring predictor has been estimated. Debt/GDP alone does not identify willingness to pay, creditor seniority, monetary regime or default resolution.')
p('<b>Legal/monetary channel.</b> France is a euro-area sovereign, unlike most of the comparator events. Normal-market OAT liquidity and euro-area institutions may support pricing, while systemic euro stress, domestic-law restructuring, creditor discrimination and dealer withdrawal may reduce realizability. We cannot credibly assign a single numerical French uplift/downlift from these opposing channels.')
p('<b>Indexed-claim channel.</b> For the first-order model, normalize proceeds by indexed face F=N x IR immediately before the trigger. This is not a claim that indexed and nominal obligations must recover identically. Recognition of indexation, coupon/accrued claims, index discontinuity, and the non-automatic application of the maturity principal floor in default are legal/model assumptions. The illustrative IR 1.3195 is dated 14 October 2026, not a future fixed parameter.')
p('<b>Execution/accessibility channel.</b> BVAL is indicative, not a firm executable bid. A staged liquidation and possible sale restrictions require judgment about realized price and whether proceeds enter the contractual waterfall on time. No direct data identify the probability of zero cash access. This is explicitly an expert-judgment tail scenario, to be challenged by the desk and legal documentation.')
h('6 | Final scenario construction and CVA illustration')
p('The scenario distribution is intentionally small: inaccessible/delayed, severe sale, distressed orderly sale, resilient sale. These states combine French market value and disposal accessibility in a <b>reduced-form recovery</b>; do not additionally deduct an unquantified execution haircut or reapply a haircut elsewhere. All weights and recovery levels below are judgmental, constrained qualitatively by event-window market prices and restructuring tails.')
for mode in ['Conservative','Balanced','Aggressive']:
 rs=[r for r in scenarios if r['mode']==mode]
 table([mode+' scenario','Probability','Accessible recovery / F'],[[r['scenario'],f"{100*float(r['probability']):.0f}%",f"{float(r['recovery_pct']):.0f}%"] for r in rs],[260,100,126])
p('Balanced: 10% no access; conditional mean recovery when accessible 40%; unconditional mean 0.9 x 40% = 36%. Conservative: 25% no access and 26.33% conditional recovery, giving 19.75%. Aggressive: 5% no access and 56.58% conditional recovery, giving 53.75%. These are <b>not statistical confidence bounds</b>.')
p('Illustration only: N=EUR 51m, IR=1.3195, F=EUR 67.2945m, V_closeout=EUR 19.62m; break-even R=29.16%. Balanced losses: no-access state contributes EUR 1.962m and severe 20%-recovery state contributes EUR 1.540m; expected loss EUR 3.502m. Conservative EUR 8.239m; Aggressive EUR 1.400m. A 36% mean recovery would yield zero loss if incorrectly applied before the positive part, which demonstrates why scenario averaging is essential.')
h('7 | Implementation boundary, validation and desk decision')
p('<b>Minimal implementation:</b> take the engine\'s close-out exposure and indexed collateral face at each relevant simulated French-default state; draw the four-state recovery conditional on default, compute available collateral proceeds and statewise positive-part loss, then aggregate using the engine\'s existing default and discounting machinery. Do not redesign XVA observation grids, event ordering or numeraire conventions for this calibration. Keep scalar 36% for reporting/sanity checks, not as a substitute for the distribution.')
p('<b>Required before production:</b> (1) confirm executed Series liquidation election, Reference Business Day calendar, collateral ownership/CSA and waterfall; (2) obtain desk sign-off on scenario values and especially 10% no-access judgment; (3) verify OAT EUR i default-claim/indexation treatment; (4) independently replicate the inputs and stress CVA across the three modes. The absence of these approvals does not require further historical-data collection to complete this research paper.')
p('<b>Conclusion:</b> Balanced 36% is a transparent, scenario-based working calibration of short-window accessible collateral proceeds. It is not a data-fitted France estimate. The calibrated object is accessible proceeds in a short contractual window, not eventual restructuring value. The standalone research is complete for decision and incorporation, subject to the enumerated desk/legal/model-validation gates.')
h('Appendix A | Evidence hierarchy and selection controls')
table(['Parameter / quantity','Evidence classification','Control'],[['BVAL quotes, event dates','Observed descriptive data','Retain source, event T0, missingness, quote type'],['Event means / tiers','Calculated / judgmental tier','Equal-event comparisons, no pseudo-replication'],['NPV haircut panel','Observed study outcomes','Source methodology, bounded modern filter'],['Debt/GDP scatter','Exploratory diagnostic','No France forecast, event selection sensitivity'],['OAT EUR i indexed face','Market/contractual input','Refresh IR, validate claim recognition'],['Scenario recovery and weights','Expert judgment informed by evidence','Explicit sign-off, sensitivity, no double haircut'],['30 TARGET-day window','Analytical assumption','Executed-Series confirmation']],[145,155,186])
h('Appendix B | Complete 22-security selection inventory')
rows=[]
for r in correct:
 cov=r.get('coverage_pct','');bid=r.get('window_mean_bid','')
 try:cov=f'{float(cov):.0f}%'
 except:pass
 try:bid=f'{float(bid):.1f}'
 except:pass
 rows.append([r['episode'],r['isin'],r['tier'],cov,bid])
table(['Event','ISIN','Tier','Coverage','Mean bid'],rows,[116,126,42,76,126])
small('Selection register is derived from supplied normalized Bloomberg histories. The v0.7 CSV had incorrectly serialized an ISIN field as a Python bound-method string; the final register corrects it using the original daily-history ISIN values. Refer to selection_register_corrected.csv for instrument descriptions and detailed restrictions.')
h('Appendix C | Definitions, data provenance and reproducibility')
p('Bloomberg source histories: SPIRE_refHistData(1).csv (Zambia/Ghana), bliq_calibration10a_histData(1).csv, 10b and 10c (five additional episodes), plus the supplied Bloomberg research summary. The new Ukraine 2024 ISINs are replacements driven by historical quote availability; they are not the same instruments as those originally requested in the summary. Dates and TARGET offsets are independently recalculated; missing quotes are not interpolated. Accrued fields exist in newer exports but cannot automatically be added to flat-traded/defaulted quotes without convention verification.')
p('Public source files: Master_Haircuts_Publication April 2025.xlsx; Cruces-Trebesch-Haircuts-2014-update.xlsx; DEBT_2025.csv. Macro event-year crosswalk is assembled from prior research iterations, with mixed source vintages and definitions. Supporting CSVs in this package preserve the original derived records, event selection, sensitivity, scenario calculations and daily quotes. Statistical independence is at the sovereign-event level; no inference assumes 22 independent sovereign defaults.')
p('The accompanying Markdown manuscript is section-modular: Sections 1-2 define the model interface; Sections 3-5 supply empirical and transfer support; Section 6 contains portable calibration parameters; Section 7 supplies the implementation and sign-off boundary. These sections may be folded into the main B(liq) white paper without relying on earlier calibration drafts.')
open(base+'/SPIRE_Bliq_Calibration_Final.md','w').write('\n'.join(md))
def footer(c,doc):
 c.setFont('Helvetica',7);c.setFillColor(colors.HexColor('#637786'));c.drawString(42,30,'SPIRE | Standalone B(liq) calibration | final | Senior quant / desk review');c.drawRightString(552,30,str(doc.page))
pdf=base+'/SPIRE_Bliq_Calibration_Final.pdf';doc=SimpleDocTemplate(pdf,pagesize=(595,842),leftMargin=42,rightMargin=42,topMargin=45,bottomMargin=46,title='SPIRE Bliq Calibration v0.8',author='Independent calibration research');doc.build(story,onFirstPage=footer,onLaterPages=footer)
with zipfile.ZipFile(base+'/SPIRE_Bliq_Calibration_Final_package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in os.listdir(base):
  if f.endswith(('.pdf','.md','.csv','.py')):z.write(base+'/'+f,arcname=f)
print('CREATED',pdf,os.path.getsize(pdf),'inventory',len(correct))
